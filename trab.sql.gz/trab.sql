-- Adminer 4.6.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `capina_e_rocada`;
CREATE TABLE `capina_e_rocada` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `manual` varchar(40) DEFAULT NULL,
  `mac` varchar(40) DEFAULT NULL,
  `quimica` varchar(40) DEFAULT NULL,
  `trabpublico` int(11) DEFAULT NULL,
  `trabprivado` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `capina_e_rocada_fk` (`id_municipio`),
  CONSTRAINT `capina_e_rocada_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `catadores`;
CREATE TABLE `catadores` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `associados` int(11) DEFAULT NULL,
  `entidades` int(11) DEFAULT NULL,
  `trabalhosocial` varchar(40) DEFAULT NULL,
  `organizacaoformal` varchar(40) DEFAULT NULL,
  `dispersos` varchar(40) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `catadores_fk` (`id_municipio`),
  CONSTRAINT `catadores_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `catadores` (`ano`, `associados`, `entidades`, `trabalhosocial`, `organizacaoformal`, `dispersos`, `id_municipio`) VALUES
(2015,	0,	0,	'Não',	'Não',	'Sim',	430080),
(2015,	25,	1,	'Sim',	'Sim',	'Não',	430210),
(2015,	0,	0,	'Não',	'Não',	'Sim',	430480),
(2015,	0,	0,	'Não',	'Não',	'Não',	430593),
(2015,	5,	1,	'Não',	'Sim',	'Sim',	430595),
(2015,	0,	0,	'Não',	'Não',	'Sim',	430786),
(2015,	15,	1,	'Não',	'Sim',	'Sim',	430860),
(2015,	0,	0,	'Não',	'Não',	'Não',	431238),
(2015,	0,	0,	'Não',	'Não',	'Sim',	431290),
(2015,	0,	0,	'Não',	'Não',	'Não',	431335),
(2015,	0,	0,	'Não',	'Não',	'Não',	431725),
(2015,	0,	0,	'Não',	'Não',	'Não',	431900),
(2015,	0,	0,	'Não',	'Não',	'Não',	432280);

DROP TABLE IF EXISTS `coleta_seletiva`;
CREATE TABLE `coleta_seletiva` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `quantSLU` int(11) DEFAULT NULL,
  `quantempresa` double DEFAULT NULL,
  `quantcatadores` int(11) DEFAULT NULL,
  `quantoutros` int(11) DEFAULT NULL,
  `populacao` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  `coleta_seletiva` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `coleta_seletiva_fk` (`id_municipio`),
  CONSTRAINT `coleta_seletiva_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `coleta_seletiva` (`ano`, `quantSLU`, `quantempresa`, `quantcatadores`, `quantoutros`, `populacao`, `id_municipio`, `coleta_seletiva`) VALUES
(2015,	0,	480,	0,	NULL,	9560,	430080,	1),
(2015,	0,	6509,	0,	NULL,	104618,	430210,	1),
(2015,	0,	5405,	0,	NULL,	21870,	430480,	1),
(2015,	NULL,	NULL,	NULL,	NULL,	NULL,	430593,	0),
(2015,	NULL,	NULL,	0,	NULL,	2014,	430595,	1),
(2015,	0,	89,	0,	NULL,	1358,	430786,	1),
(2015,	0,	1782,	0,	NULL,	29138,	430860,	1),
(2015,	0,	124,	0,	NULL,	780,	431238,	1),
(2015,	0,	487,	0,	22,	5912,	431290,	1),
(2015,	0,	368,	0,	NULL,	1690,	431335,	1),
(2015,	0,	63,	0,	NULL,	649,	431725,	1),
(2015,	0,	813,	0,	NULL,	18562,	431900,	1),
(2015,	0,	180,	0,	NULL,	NULL,	432280,	1);

DROP TABLE IF EXISTS `despesas_com_manejo_residuos_solidos`;
CREATE TABLE `despesas_com_manejo_residuos_solidos` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `tipopublicoprivado` varchar(40) NOT NULL DEFAULT '',
  `tiposervico` varchar(40) NOT NULL DEFAULT '',
  `valor` float DEFAULT NULL,
  `valorpuplicoprivado` float DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`,`tipopublicoprivado`,`tiposervico`),
  KEY `despesas_com_manejo_residuos_solidos_fk` (`id_municipio`),
  CONSTRAINT `despesas_com_manejo_residuos_solidos_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `despesas_com_manejo_residuos_solidos` (`ano`, `tipopublicoprivado`, `tiposervico`, `valor`, `valorpuplicoprivado`, `id_municipio`) VALUES
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	941644,	NULL,	430080),
(2015,	'privado',	'Coleta de RS serviço de saúde',	2821.53,	NULL,	430080),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	430080),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	430080),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	941644,	0,	430080),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	430080),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	430080),
(2015,	'publico',	'Varrição de logradouros públicos',	142387,	NULL,	430080),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	9517250,	NULL,	430210),
(2015,	'privado',	'Coleta de RS serviço de saúde',	47234,	NULL,	430210),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	3238350,	NULL,	430210),
(2015,	'privado',	'Varrição de logradouros públicos',	937155,	NULL,	430210),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	9.517,	0,	430210),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	430210),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	430210),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	430210),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	0,	NULL,	430480),
(2015,	'privado',	'Coleta de RS serviço de saúde',	0,	NULL,	430480),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	430480),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	430480),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	2602180,	NULL,	430480),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	430480),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	430480),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	430480),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	59806.5,	NULL,	430593),
(2015,	'privado',	'Coleta de RS serviço de saúde',	2412.48,	NULL,	430593),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	430593),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	430593),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	59.806,	0,	430593),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	430593),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	430593),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	430593),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	317215,	NULL,	430595),
(2015,	'privado',	'Coleta de RS serviço de saúde',	3072.68,	NULL,	430595),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	430595),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	430595),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	317215,	0,	430595),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	430595),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	430595),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	430595),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	167956,	NULL,	430786),
(2015,	'privado',	'Coleta de RS serviço de saúde',	3552.84,	NULL,	430786),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	430786),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	430786),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	167.955,	0,	430786),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	430786),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	430786),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	430786),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	0,	NULL,	430860),
(2015,	'privado',	'Coleta de RS serviço de saúde',	0,	NULL,	430860),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	430860),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	430860),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	1415940,	NULL,	430860),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	430860),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	430860),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	430860),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	312043,	NULL,	431238),
(2015,	'privado',	'Coleta de RS serviço de saúde',	4569.72,	NULL,	431238),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	431238),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	431238),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	312.042,	0,	431238),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	431238),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	431238),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	431238),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	744028,	NULL,	431290),
(2015,	'privado',	'Coleta de RS serviço de saúde',	7436.01,	NULL,	431290),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	431290),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	431290),
(2015,	'Público',	'Coleta de RS domiciliares e públicos',	803.528,	59.5,	431290),
(2015,	'publico',	'Coleta de RS serviço de saúde',	40000,	NULL,	431290),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	1400,	NULL,	431290),
(2015,	'publico',	'Varrição de logradouros públicos',	39000,	NULL,	431290),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	168000,	NULL,	431335),
(2015,	'privado',	'Coleta de RS serviço de saúde',	9000,	NULL,	431335),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	48000,	NULL,	431335),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	431335),
(2015,	'publico',	'Coleta de RS domiciliares e públicos',	0,	NULL,	431335),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	431335),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	431335),
(2015,	'publico',	'Varrição de logradouros públicos',	20000,	NULL,	431335),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	0,	NULL,	431725),
(2015,	'privado',	'Coleta de RS serviço de saúde',	0,	NULL,	431725),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	431725),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	431725),
(2015,	'publico',	'Coleta de RS domiciliares e públicos',	0,	NULL,	431725),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	431725),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	431725),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	431725),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	0,	NULL,	431900),
(2015,	'privado',	'Coleta de RS serviço de saúde',	0,	NULL,	431900),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	431900),
(2015,	'privado',	'Varrição de logradouros públicos',	0,	NULL,	431900),
(2015,	'publico',	'Coleta de RS domiciliares e públicos',	0,	NULL,	431900),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	431900),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	431900),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	431900),
(2015,	'privado',	'Coleta de RS domiciliares e públicos',	1940710,	NULL,	432280),
(2015,	'privado',	'Coleta de RS serviço de saúde',	10000,	NULL,	432280),
(2015,	'privado',	'Demais serviços, inclusive administrativ',	0,	NULL,	432280),
(2015,	'privado',	'Varrição de logradouros públicos',	123431,	NULL,	432280),
(2015,	'publico',	'Coleta de RS domiciliares e públicos',	0,	NULL,	432280),
(2015,	'publico',	'Coleta de RS serviço de saúde',	0,	NULL,	432280),
(2015,	'publico',	'Demais serviços, inclusive administrativ',	0,	NULL,	432280),
(2015,	'publico',	'Varrição de logradouros públicos',	0,	NULL,	432280);

DROP TABLE IF EXISTS `despesas_limpeza_urbana`;
CREATE TABLE `despesas_limpeza_urbana` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `tipo` varchar(40) NOT NULL DEFAULT '',
  `valor` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`,`tipo`),
  KEY `despesas_limpeza_urbana_fk` (`id_municipio`),
  CONSTRAINT `despesas_limpeza_urbana_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `despesas_limpeza_urbana` (`ano`, `tipo`, `valor`, `id_municipio`) VALUES
(2015,	'privado',	944466,	430080),
(2015,	'publico',	142387,	430080),
(2015,	'privado',	13739987,	430210),
(2015,	'publico',	0,	430210),
(2015,	'privado',	0,	430480),
(2015,	'publico',	0,	430480),
(2015,	'privado',	62219,	430593),
(2015,	'publico',	0,	430593),
(2015,	'privado',	320288,	430595),
(2015,	'publico',	0,	430595),
(2015,	'privado',	0,	430786),
(2015,	'publico',	0,	430786),
(2015,	'privado',	0,	430860),
(2015,	'publico',	0,	430860),
(2015,	'privado',	316613,	431238),
(2015,	'publico',	0,	431238),
(2015,	'privado',	751464,	431290),
(2015,	'publico',	139900,	431290),
(2015,	'privado',	225000,	431335),
(2015,	'publico',	20000,	431335),
(2015,	'privado',	0,	431725),
(2015,	'publico',	0,	431725),
(2015,	'privado',	0,	431900),
(2015,	'publico',	0,	431900),
(2015,	'privado',	2074137,	432280),
(2015,	'publico',	0,	432280);

DROP TABLE IF EXISTS `forma_de_execucao`;
CREATE TABLE `forma_de_execucao` (
  `formaexecucao` varchar(40) NOT NULL DEFAULT '',
  `catadorescomapoio` varchar(40) DEFAULT NULL,
  `catadoressemapoio` varchar(40) DEFAULT NULL,
  `prefoucontratada` varchar(40) DEFAULT NULL,
  `emprramosucateiros` varchar(40) DEFAULT NULL,
  `outroexecutor` varchar(40) DEFAULT NULL,
  `ano` int(11) NOT NULL DEFAULT '0',
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`formaexecucao`,`ano`,`id_municipio`),
  KEY `forma_de_execucao_fk` (`ano`,`id_municipio`),
  CONSTRAINT `forma_de_execucao_fk` FOREIGN KEY (`ano`, `id_municipio`) REFERENCES `coleta_seletiva` (`ano`, `id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `frente_trabalho_temporario`;
CREATE TABLE `frente_trabalho_temporario` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `id_frente` int(11) DEFAULT NULL,
  `qtd_frente` int(11) DEFAULT NULL,
  `duracaomeses_frente` int(11) DEFAULT NULL,
  `servicopredom` varchar(40) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `frente_trabalho_temporario_fk` (`id_municipio`),
  CONSTRAINT `frente_trabalho_temporario_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `informacoes_diversas`;
CREATE TABLE `informacoes_diversas` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `valorservicotransporte` int(11) DEFAULT NULL,
  `distanciaservicostransporte` int(11) DEFAULT NULL,
  `tipodomicpublic` varchar(40) DEFAULT NULL,
  `valorcoletaterceiriz` int(11) DEFAULT NULL,
  `valorservicodisposicaoaterro` int(11) DEFAULT NULL,
  `usobalanca` varchar(40) DEFAULT NULL,
  `municipioremessa` varchar(40) DEFAULT NULL,
  `valorterceirizcoletaRDO_RPU` int(11) DEFAULT NULL,
  `incluidotranspRDO_RPU` int(11) DEFAULT NULL,
  `distanciamedRDO_RPU` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `informacoes_diversas_fk` (`id_municipio`),
  CONSTRAINT `informacoes_diversas_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `material_recuperado`;
CREATE TABLE `material_recuperado` (
  `tipo` varchar(40) NOT NULL DEFAULT '',
  `quantidade` int(11) DEFAULT NULL,
  `ano` int(11) NOT NULL DEFAULT '0',
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tipo`,`ano`,`id_municipio`),
  KEY `material_recuperado_fk` (`ano`,`id_municipio`),
  CONSTRAINT `material_recuperado_fk` FOREIGN KEY (`ano`, `id_municipio`) REFERENCES `coleta_seletiva` (`ano`, `id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `municipio`;
CREATE TABLE `municipio` (
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  `nome` varchar(100) DEFAULT NULL,
  `uf` varchar(40) DEFAULT NULL,
  `codregiao` int(11) DEFAULT NULL,
  `nomeorgaogestao` varchar(100) DEFAULT NULL,
  `siglaorgao` varchar(40) DEFAULT NULL,
  `naturezajuridica` varchar(40) DEFAULT NULL,
  `cobrancaregularexist` varchar(40) DEFAULT NULL,
  `cobrancaregularforma` varchar(40) DEFAULT NULL,
  `cobrancaespecial` varchar(40) DEFAULT NULL,
  `despesacorrenteprefeitura` int(11) DEFAULT NULL,
  `servicoconcedido` varchar(40) DEFAULT NULL,
  `aguaesgoto` varchar(40) DEFAULT NULL,
  `populacaourbana` int(11) DEFAULT NULL,
  `populacaototal` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `municipio` (`id_municipio`, `nome`, `uf`, `codregiao`, `nomeorgaogestao`, `siglaorgao`, `naturezajuridica`, `cobrancaregularexist`, `cobrancaregularforma`, `cobrancaespecial`, `despesacorrenteprefeitura`, `servicoconcedido`, `aguaesgoto`, `populacaourbana`, `populacaototal`) VALUES
(430080,	' Antônio Prado  ',	'RS',	4,	' Secretaria de Agricultura, Meio Ambiente e Desenvolvimento Industrial  ',	' SAMADI  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	33875969,	' Não  ',	' Não  ',	9560,	13285),
(430210,	' Bento Gonçalves  ',	'RS',	4,	' Secretaria Municipal do Meio Ambiente  ',	' SMMAM  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	284579823,	' Sim  ',	' Não  ',	104618,	113287),
(430480,	' Carlos Barbosa  ',	'RS',	4,	' Prefeitura Municipal de Carlos Barbosa  ',	' PMCB  ',	'Administração pública direta',	' Não  ',	'   ',	'Não',	99850000,	' Não  ',	' Esgotamento Sanitário  ',	21875,	27565),
(430593,	' Coronel Pilar  ',	'RS',	4,	' Prefeitura Municipal de Coronel Pilar  ',	' PMCP  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	10628751,	' Não  ',	' Abastecimento de Água  ',	176,	1740),
(430595,	' Cotiporã  ',	'RS',	4,	' Prefeitura Municipal de Cotiporã  ',	' PMCOT  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	13223347,	' Não  ',	' Não  ',	2096,	4009),
(430786,	' Fagundes Varela  ',	'RS',	4,	' MUNICÍPIO DE FAGUNDES VARELA  ',	' MFV  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	11742451,	' Não  ',	' Não  ',	1358,	2708),
(430860,	' Garibaldi  ',	'RS',	4,	' Prefeitura Municipal de Garibaldi  ',	' SMMA  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	89513405,	' Sim  ',	' Esgotamento Sanitário  ',	29376,	33131),
(431238,	' Monte Belo do Sul  ',	'RS',	4,	' Prefeitura Municipal de Monte Belo do Sul  ',	' PMMBS  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	10666577,	' Não  ',	' Abast. Água e Esg. Sanitário  ',	780,	2704),
(431290,	' Nova Bassano  ',	'RS',	4,	' Prefeitura Municipal de Nova Bassano  ',	' PMNB  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	30521941,	' Não  ',	' Não  ',	5912,	9478),
(431335,	' Nova Roma do Sul  ',	'RS',	4,	' Secretaria da Saúde e assistência Social  ',	' SMSAS  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	13482075,	' Não  ',	' Não  ',	1690,	3564),
(431725,	' Santa Tereza  ',	'RS',	4,	' Prefeitura Municipal de Santa Tereza  ',	' PMST  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	9628214,	' Não  ',	' Não  ',	649,	1781),
(431900,	' São Marcos  ',	'RS',	4,	' Prefeitura Municipal de São Marcos  ',	' PMSM  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	50555320,	' Sim  ',	' Abast. Água e Esg. Sanitário  ',	18562,	21204),
(432280,	' Veranópolis  ',	'RS',	4,	' Secretaria Municipal de Agricultura e Meio Ambiente  ',	' SMAMA  ',	'Administração pública direta',	' Sim  ',	' Taxa específica no mesmo boleto do IPTU',	'Não',	78000000,	' Não  ',	' Não  ',	21475,	24686);

DROP TABLE IF EXISTS `outros_servicos_de_manejo`;
CREATE TABLE `outros_servicos_de_manejo` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `nome` varchar(40) DEFAULT NULL,
  `quemexecuta` varchar(40) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `outros_servicos_de_manejo_fk` (`id_municipio`),
  CONSTRAINT `outros_servicos_de_manejo_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `populacao_atendida`;
CREATE TABLE `populacao_atendida` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `coletaelevconteiner` varchar(40) DEFAULT NULL,
  `coletanoturna` varchar(40) DEFAULT NULL,
  `atend1X` int(11) DEFAULT NULL,
  `atend3X` int(11) DEFAULT NULL,
  `atenddiaria` int(11) DEFAULT NULL,
  `urbanadireta` int(11) DEFAULT NULL,
  `urbanamunic` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `populacao_atendida_fk` (`id_municipio`),
  CONSTRAINT `populacao_atendida_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `populacao_atendida` (`ano`, `coletaelevconteiner`, `coletanoturna`, `atend1X`, `atend3X`, `atenddiaria`, `urbanadireta`, `urbanamunic`, `total`, `id_municipio`) VALUES
(2015,	'Sim',	'Sim',	0,	0,	100,	9560,	9560,	13285,	430080),
(2015,	'Não',	'Sim',	2,	26,	73,	104618,	104618,	113287,	430210),
(2015,	'Sim',	'Não',	21,	63,	16,	5690,	21875,	27565,	430480),
(2015,	'Não',	'Não',	0,	100,	0,	176,	176,	176,	430593),
(2015,	'Não',	'Não',	42,	58,	0,	2014,	2096,	4009,	430595),
(2015,	'Não',	'Não',	0,	100,	0,	1358,	1358,	1358,	430786),
(2015,	'Sim',	'Não',	5,	45,	50,	29376,	29376,	33131,	430860),
(2015,	'Não',	'Não',	0,	100,	0,	780,	780,	780,	431238),
(2015,	'Não',	'Não',	41,	1,	59,	4138,	5912,	9478,	431290),
(2015,	'Não',	'Não',	0,	100,	0,	1690,	1690,	1690,	431335),
(2015,	'Não',	'Não',	0,	100,	0,	649,	649,	649,	431725),
(2015,	'Não',	'Não',	5,	35,	60,	18562,	18562,	18562,	431900),
(2015,	'Não',	'Não',	0,	20,	80,	0,	21475,	24686,	432280);

DROP TABLE IF EXISTS `receitas_limpeza_urbana`;
CREATE TABLE `receitas_limpeza_urbana` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `orcada` int(11) DEFAULT NULL,
  `arrecadada` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `receitas_limpeza_urbana_fk` (`id_municipio`),
  CONSTRAINT `receitas_limpeza_urbana_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `receitas_limpeza_urbana` (`ano`, `orcada`, `arrecadada`, `id_municipio`) VALUES
(2015,	335000,	336009,	430080),
(2015,	9517251,	14611622,	430210),
(2015,	0,	0,	430480),
(2015,	6998,	6998,	430593),
(2015,	112319,	107826,	430595),
(2015,	50000,	33459,	430786),
(2015,	2164900,	2348836,	430860),
(2015,	75000,	75868,	431238),
(2015,	225000,	253284,	431290),
(2015,	25000,	18000,	431335),
(2015,	20000,	12300,	431725),
(2015,	715000,	514947,	431900),
(2015,	836000,	947792,	432280);

DROP TABLE IF EXISTS `residuos_solidos`;
CREATE TABLE `residuos_solidos` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `coletaRPUcomRDO` varchar(40) DEFAULT NULL,
  `qtdprefeitura` int(11) DEFAULT NULL,
  `qtdempresa` int(11) DEFAULT NULL,
  `qtdassomoradores` int(11) DEFAULT NULL,
  `qtdoutros` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `residuos_solidos_fk` (`id_municipio`),
  CONSTRAINT `residuos_solidos_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `residuos_solidos` (`ano`, `coletaRPUcomRDO`, `qtdprefeitura`, `qtdempresa`, `qtdassomoradores`, `qtdoutros`, `id_municipio`) VALUES
(2015,	'0',	25,	2256,	0,	0,	430080),
(2015,	'1',	0,	32803,	0,	0,	430210),
(2015,	'0',	0,	5045,	0,	0,	430480),
(2015,	'1',	0,	199,	0,	0,	430593),
(2015,	'0',	0,	750,	0,	0,	430595),
(2015,	'1',	0,	917,	0,	0,	430786),
(2015,	'0',	0,	7226,	0,	0,	430860),
(2015,	'0',	0,	690,	0,	0,	431238),
(2015,	'1',	30,	1920,	0,	22,	431290),
(2015,	'1',	0,	510,	0,	0,	431335),
(2015,	'0',	0,	239,	0,	0,	431725),
(2015,	'0',	5,	3265,	0,	0,	431900),
(2015,	'0',	0,	5760,	0,	0,	432280);

DROP TABLE IF EXISTS `servico_coleta`;
CREATE TABLE `servico_coleta` (
  `tipo` varchar(40) NOT NULL DEFAULT '',
  `valorcontrato` int(11) DEFAULT NULL,
  `valortriagem` int(11) DEFAULT NULL,
  `ano` int(11) NOT NULL DEFAULT '0',
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tipo`,`ano`,`id_municipio`),
  KEY `servico_coleta_fk` (`ano`,`id_municipio`),
  CONSTRAINT `servico_coleta_fk` FOREIGN KEY (`ano`, `id_municipio`) REFERENCES `coleta_seletiva` (`ano`, `id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `trabalhadores_remunerados`;
CREATE TABLE `trabalhadores_remunerados` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `tipopublicoprivado` varchar(40) NOT NULL DEFAULT '',
  `natureza` varchar(40) NOT NULL DEFAULT '',
  `qnt` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`,`tipopublicoprivado`,`natureza`),
  KEY `trabalhadores_remunerados_fk` (`id_municipio`),
  CONSTRAINT `trabalhadores_remunerados_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `trabalhadores_remunerados` (`ano`, `tipopublicoprivado`, `natureza`, `qnt`, `id_municipio`) VALUES
(2015,	'privado',	'Capina',	0,	430080),
(2015,	'privado',	'coleta',	10,	430080),
(2015,	'privado',	'Geren.',	1,	430080),
(2015,	'privado',	'Outros',	0,	430080),
(2015,	'privado',	'Unidades',	0,	430080),
(2015,	'privado',	'Varrição',	0,	430080),
(2015,	'publico',	'Capina',	5,	430080),
(2015,	'publico',	'coleta',	0,	430080),
(2015,	'publico',	'Geren.',	2,	430080),
(2015,	'publico',	'Outros',	0,	430080),
(2015,	'publico',	'Unidades',	0,	430080),
(2015,	'publico',	'Varrição',	2,	430080),
(2015,	'privado',	'Capina',	37,	430210),
(2015,	'privado',	'coleta',	70,	430210),
(2015,	'privado',	'Geren.',	17,	430210),
(2015,	'privado',	'Outros',	0,	430210),
(2015,	'privado',	'Unidades',	1,	430210),
(2015,	'privado',	'Varrição',	41,	430210),
(2015,	'publico',	'Capina',	0,	430210),
(2015,	'publico',	'coleta',	0,	430210),
(2015,	'publico',	'Geren.',	0,	430210),
(2015,	'publico',	'Outros',	0,	430210),
(2015,	'publico',	'Unidades',	0,	430210),
(2015,	'publico',	'Varrição',	0,	430210),
(2015,	'privado',	'Capina',	1,	430480),
(2015,	'privado',	'coleta',	16,	430480),
(2015,	'privado',	'Geren.',	3,	430480),
(2015,	'privado',	'Outros',	0,	430480),
(2015,	'privado',	'Unidades',	8,	430480),
(2015,	'privado',	'Varrição',	3,	430480),
(2015,	'publico',	'Capina',	0,	430480),
(2015,	'publico',	'coleta',	0,	430480),
(2015,	'publico',	'Geren.',	0,	430480),
(2015,	'publico',	'Outros',	0,	430480),
(2015,	'publico',	'Unidades',	0,	430480),
(2015,	'publico',	'Varrição',	0,	430480),
(2015,	'privado',	'Capina',	0,	430593),
(2015,	'privado',	'coleta',	0,	430593),
(2015,	'privado',	'Geren.',	0,	430593),
(2015,	'privado',	'Outros',	0,	430593),
(2015,	'privado',	'Unidades',	0,	430593),
(2015,	'privado',	'Varrição',	0,	430593),
(2015,	'publico',	'Capina',	0,	430593),
(2015,	'publico',	'coleta',	1,	430593),
(2015,	'publico',	'Geren.',	0,	430593),
(2015,	'publico',	'Outros',	0,	430593),
(2015,	'publico',	'Unidades',	0,	430593),
(2015,	'publico',	'Varrição',	0,	430593),
(2015,	'privado',	'Capina',	0,	430595),
(2015,	'privado',	'coleta',	3,	430595),
(2015,	'privado',	'Geren.',	0,	430595),
(2015,	'privado',	'Outros',	0,	430595),
(2015,	'privado',	'Unidades',	0,	430595),
(2015,	'privado',	'Varrição',	0,	430595),
(2015,	'publico',	'Capina',	0,	430595),
(2015,	'publico',	'coleta',	0,	430595),
(2015,	'publico',	'Geren.',	0,	430595),
(2015,	'publico',	'Outros',	0,	430595),
(2015,	'publico',	'Unidades',	0,	430595),
(2015,	'publico',	'Varrição',	0,	430595),
(2015,	'privado',	'Capina',	0,	430786),
(2015,	'privado',	'coleta',	0,	430786),
(2015,	'privado',	'Outros',	0,	430786),
(2015,	'privado',	'Unidades',	0,	430786),
(2015,	'privado',	'Varrição',	0,	430786),
(2015,	'publico',	'Capina',	0,	430786),
(2015,	'publico',	'coleta',	0,	430786),
(2015,	'publico',	'Geren.',	0,	430786),
(2015,	'publico',	'Outros',	0,	430786),
(2015,	'publico',	'Unidades',	0,	430786),
(2015,	'publico',	'Varrição',	0,	430786),
(2015,	'privado',	'Capina',	8,	430860),
(2015,	'privado',	'coleta',	16,	430860),
(2015,	'privado',	'Geren.',	0,	430860),
(2015,	'privado',	'Outros',	0,	430860),
(2015,	'privado',	'Unidades',	0,	430860),
(2015,	'privado',	'Varrição',	8,	430860),
(2015,	'publico',	'Capina',	2,	430860),
(2015,	'publico',	'coleta',	0,	430860),
(2015,	'publico',	'Geren.',	0,	430860),
(2015,	'publico',	'Outros',	0,	430860),
(2015,	'publico',	'Unidades',	0,	430860),
(2015,	'publico',	'Varrição',	2,	430860),
(2015,	'privado',	'Capina',	0,	431238),
(2015,	'privado',	'coleta',	0,	431238),
(2015,	'privado',	'Geren.',	0,	431238),
(2015,	'privado',	'Outros',	0,	431238),
(2015,	'privado',	'Unidades',	0,	431238),
(2015,	'privado',	'Varrição',	0,	431238),
(2015,	'publico',	'Capina',	1,	431238),
(2015,	'publico',	'coleta',	3,	431238),
(2015,	'publico',	'Geren.',	1,	431238),
(2015,	'publico',	'Outros',	0,	431238),
(2015,	'publico',	'Unidades',	0,	431238),
(2015,	'publico',	'Varrição',	1,	431238),
(2015,	'privado',	'Capina',	0,	431290),
(2015,	'privado',	'coleta',	4,	431290),
(2015,	'privado',	'Geren.',	1,	431290),
(2015,	'privado',	'Outros',	0,	431290),
(2015,	'privado',	'Unidades',	20,	431290),
(2015,	'privado',	'Varrição',	0,	431290),
(2015,	'publico',	'Capina',	1,	431290),
(2015,	'publico',	'coleta',	1,	431290),
(2015,	'publico',	'Geren.',	1,	431290),
(2015,	'publico',	'Outros',	0,	431290),
(2015,	'publico',	'Unidades',	0,	431290),
(2015,	'publico',	'Varrição',	1,	431290),
(2015,	'privado',	'Capina',	0,	431335),
(2015,	'privado',	'coleta',	2,	431335),
(2015,	'privado',	'Geren.',	0,	431335),
(2015,	'privado',	'Outros',	0,	431335),
(2015,	'privado',	'Unidades',	2,	431335),
(2015,	'privado',	'Varrição',	0,	431335),
(2015,	'publico',	'Capina',	1,	431335),
(2015,	'publico',	'coleta',	0,	431335),
(2015,	'publico',	'Geren.',	0,	431335),
(2015,	'publico',	'Outros',	1,	431335),
(2015,	'publico',	'Unidades',	0,	431335),
(2015,	'publico',	'Varrição',	1,	431335),
(2015,	'privado',	'Capina',	3,	431725),
(2015,	'privado',	'coleta',	3,	431725),
(2015,	'privado',	'Geren.',	0,	431725),
(2015,	'privado',	'Outros',	0,	431725),
(2015,	'privado',	'Unidades',	0,	431725),
(2015,	'privado',	'Varrição',	2,	431725),
(2015,	'publico',	'Capina',	0,	431725),
(2015,	'publico',	'coleta',	1,	431725),
(2015,	'publico',	'Geren.',	0,	431725),
(2015,	'publico',	'Outros',	0,	431725),
(2015,	'publico',	'Unidades',	0,	431725),
(2015,	'publico',	'Varrição',	0,	431725),
(2015,	'privado',	'Capina',	0,	431900),
(2015,	'privado',	'coleta',	16,	431900),
(2015,	'privado',	'Geren.',	2,	431900),
(2015,	'privado',	'Outros',	1,	431900),
(2015,	'privado',	'Unidades',	9,	431900),
(2015,	'privado',	'Varrição',	0,	431900),
(2015,	'publico',	'Capina',	5,	431900),
(2015,	'publico',	'coleta',	0,	431900),
(2015,	'publico',	'Geren.',	1,	431900),
(2015,	'publico',	'Outros',	0,	431900),
(2015,	'publico',	'Unidades',	0,	431900),
(2015,	'publico',	'Varrição',	2,	431900),
(2015,	'privado',	'Capina',	0,	432280),
(2015,	'privado',	'coleta',	7,	432280),
(2015,	'privado',	'Geren.',	1,	432280),
(2015,	'privado',	'Outros',	0,	432280),
(2015,	'privado',	'Unidades',	0,	432280),
(2015,	'privado',	'Varrição',	4,	432280),
(2015,	'publico',	'Capina',	0,	432280),
(2015,	'publico',	'coleta',	0,	432280),
(2015,	'publico',	'Geren.',	0,	432280),
(2015,	'publico',	'Outros',	0,	432280),
(2015,	'publico',	'Unidades',	0,	432280),
(2015,	'publico',	'Varrição',	0,	432280);

DROP TABLE IF EXISTS `varricao`;
CREATE TABLE `varricao` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `extensaoprivado` int(11) DEFAULT NULL,
  `extensaopublico` int(11) DEFAULT NULL,
  `varredprivado` int(11) DEFAULT NULL,
  `varredpublico` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `varricao_fk` (`id_municipio`),
  CONSTRAINT `varricao_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `veiculos_agentes_privados`;
CREATE TABLE `veiculos_agentes_privados` (
  `ano` int(11) NOT NULL DEFAULT '0',
  `agentepubpriv` varchar(40) DEFAULT NULL,
  `tipo` varchar(40) DEFAULT NULL,
  `capacidade` int(11) DEFAULT NULL,
  `quant` int(11) DEFAULT NULL,
  `id_municipio` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`id_municipio`),
  KEY `veiculos_agentes_privados_fk` (`id_municipio`),
  CONSTRAINT `veiculos_agentes_privados_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2018-07-09 15:53:52
